<div class="container-fluid mt-2">
    <div class="text-end mb-2 ">
        Copyright © {{ Date('Y') }}
        <a class="footer-link" href="#">Q-Softwares</a>
    </div>
</div>
